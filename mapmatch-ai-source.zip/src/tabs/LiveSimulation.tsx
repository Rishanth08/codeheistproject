import { useEffect, useRef, useState } from 'react';
import {
  Gauge,
  Navigation,
  Mountain,
  Radar,
  Play,
  Pause,
  RotateCcw,
  ChevronDown,
  Zap,
  Cpu,
  Waves,
  TrendingUp,
} from 'lucide-react';
import MapView from '@/components/MapView';
import { Badge, Card, ProgressBar } from '@/components/ui';
import { Simulator, type SimSnapshot } from '@/sim/simulator';
import { SCENARIOS, type Scenario, type VehicleState } from '@/sim/types';

export default function LiveSimulation() {
  const [scenario, setScenario] = useState<Scenario>(SCENARIOS[0]);
  const [running, setRunning] = useState(false);
  const [speedFactor, setSpeedFactor] = useState(2);
  const [snap, setSnap] = useState<SimSnapshot | null>(null);
  const [scenarioOpen, setScenarioOpen] = useState(false);
  const [progress, setProgress] = useState(0);

  const simRef = useRef<Simulator | null>(null);
  const rafRef = useRef<number | null>(null);
  const lastTickRef = useRef<number>(0);

  // init simulator
  useEffect(() => {
    const sim = new Simulator(scenario);
    sim.setSpeedFactor(speedFactor);
    simRef.current = sim;
    const s = sim.tick();
    setSnap(s);
    setProgress(0);
  }, []);

  // scenario change
  const changeScenario = (s: Scenario) => {
    setScenario(s);
    simRef.current?.setScenario(s);
    simRef.current?.setSpeedFactor(speedFactor);
    const snap0 = simRef.current?.tick();
    if (snap0) {
      setSnap(snap0);
      setProgress(0);
    }
    setScenarioOpen(false);
    setRunning(false);
  };

  // speed change
  useEffect(() => {
    simRef.current?.setSpeedFactor(speedFactor);
  }, [speedFactor]);

  // animation loop
  useEffect(() => {
    if (!running) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      return;
    }

    const loop = (ts: number) => {
      if (!lastTickRef.current) lastTickRef.current = ts;
      const dt = ts - lastTickRef.current;
      // tick every ~180ms
      if (dt > 180) {
        lastTickRef.current = ts;
        const sim = simRef.current;
        if (sim) {
          if (sim.isFinished()) {
            sim.reset();
          }
          const s = sim.tick();
          setSnap(s);
          setProgress(sim.getProgress());
        }
      }
      rafRef.current = requestAnimationFrame(loop);
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      lastTickRef.current = 0;
    };
  }, [running]);

  const vehicle: VehicleState | null = snap?.vehicle ?? null;
  const roads = simRef.current?.getRoadPaths();

  const handleReset = () => {
    simRef.current?.reset();
    const s = simRef.current?.tick();
    if (s) setSnap(s);
    setProgress(0);
    setRunning(false);
  };

  return (
    <div className="flex flex-col h-full animate-fade-in">
      {/* Top control bar */}
      <div className="glass-strong border-b border-sky-500/15 px-5 py-3 flex items-center gap-3 flex-wrap z-20">
        <div className="flex items-center gap-2">
          <Radar className="w-5 h-5 text-sky-400" />
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight">Live Simulation</h2>
            <p className="text-[10px] text-slate-500">Real-time HMM + ML map-matching engine</p>
          </div>
        </div>

        <div className="w-px h-8 bg-sky-500/15 mx-1" />

        {/* Scenario dropdown */}
        <div className="relative">
          <button
            onClick={() => setScenarioOpen((o) => !o)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg glass hover:border-sky-500/30 transition-all min-w-[200px]"
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <div className="text-left flex-1">
              <div className="text-[9px] text-slate-500 uppercase tracking-wider">Scenario</div>
              <div className="text-xs font-semibold text-white">{scenario.name}</div>
            </div>
            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${scenarioOpen ? 'rotate-180' : ''}`} />
          </button>
          {scenarioOpen && (
            <div className="absolute top-full mt-1.5 left-0 w-80 glass-strong rounded-xl p-1.5 z-30 shadow-2xl animate-fade-in">
              {SCENARIOS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => changeScenario(s)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg transition-all ${
                    s.id === scenario.id ? 'bg-sky-500/15 text-white' : 'text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <div className="text-xs font-semibold">{s.name}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">{s.description}</div>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex-1" />

        {/* Speed control */}
        <div className="flex items-center gap-1.5 glass rounded-lg px-2 py-1.5">
          <span className="text-[10px] text-slate-500 uppercase tracking-wider mr-1">Speed</span>
          {[1, 2, 4, 8].map((f) => (
            <button
              key={f}
              onClick={() => setSpeedFactor(f)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all ${
                speedFactor === f
                  ? 'bg-sky-500 text-white'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {f}x
            </button>
          ))}
        </div>

        {/* Play/pause + reset */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setRunning((r) => !r)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
              running
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30 glow-cyan'
            }`}
          >
            {running ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {running ? 'Pause' : 'Start'}
          </button>
          <button
            onClick={handleReset}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-slate-400 hover:text-white glass transition-all"
            title="Reset"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main split */}
      <div className="flex-1 flex overflow-hidden">
        {/* Map */}
        <div className="flex-1 relative">
          {roads && vehicle && (
            <MapView
              highwayPath={roads.highway}
              servicePath={roads.service}
              rawPath={snap?.rawPath ?? []}
              matchedPath={snap?.matchedPath ?? []}
              vehiclePos={vehicle.position}
              vehicleRaw={vehicle.rawGps}
              roadClass={vehicle.roadClass}
            />
          )}

          {/* Progress bar overlay */}
          <div className="absolute bottom-0 left-0 right-0 z-10 px-4 py-3 bg-gradient-to-t from-[#070b14] to-transparent">
            <div className="flex items-center gap-3">
              <span className="text-[10px] text-slate-400 font-medium tabular-nums w-10">
                {Math.round(progress * 100)}%
              </span>
              <ProgressBar value={progress} className="flex-1" />
              <span className="text-[10px] text-slate-500 tabular-nums">
                {vehicle ? `${(vehicle.distanceTraveled / 1000).toFixed(2)} km` : '0.00 km'}
              </span>
            </div>
          </div>

          {/* Legend overlay */}
          <div className="absolute top-4 left-4 z-10 glass rounded-xl p-3 space-y-2">
            <div className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold mb-1">Legend</div>
            <LegendItem color="#f43f5e" label="Raw GPS (noisy)" dashed />
            <LegendItem color="#2563eb" label="AI Map-Matched" />
            <LegendItem color="#64748b" label="Service Road" thin />
            <LegendItem color="#fbbf24" label="Highway" thin />
          </div>

          {/* Road classification overlay */}
          {vehicle && (
            <div className="absolute top-4 right-4 z-10 glass-strong rounded-xl p-3 min-w-[180px]">
              <div className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold mb-2">
                Current Classification
              </div>
              <div className="flex items-center justify-between">
                <span
                  className={`text-base font-bold ${
                    vehicle.roadClass === 'highway' ? 'text-sky-400' : 'text-teal-400'
                  }`}
                >
                  {vehicle.roadClass === 'highway' ? 'Highway' : 'Service Road'}
                </span>
                <Badge color={vehicle.confidence > 0.9 ? 'emerald' : 'amber'}>
                  {(vehicle.confidence * 100).toFixed(1)}%
                </Badge>
              </div>
              <ProgressBar
                value={vehicle.confidence}
                color={
                  vehicle.roadClass === 'highway'
                    ? 'from-sky-500 to-sky-400'
                    : 'from-teal-500 to-teal-400'
                }
                className="mt-2"
              />
            </div>
          )}
        </div>

        {/* Right telemetry panel */}
        <div className="w-96 shrink-0 overflow-y-auto scrollbar-thin glass-strong border-l border-sky-500/15 p-4 space-y-3">
          <div className="flex items-center gap-2 pb-2">
            <Cpu className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm font-bold text-white tracking-tight">Telemetry</h3>
            <span className="flex items-center gap-1 ml-auto">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse-slow" />
              <span className="text-[10px] text-emerald-400">LIVE</span>
            </span>
          </div>

          {vehicle && (
            <>
              <TelemetryCard
                icon={<Gauge className="w-4 h-4" />}
                label="Speed"
                value={vehicle.speed.toFixed(1)}
                unit="km/h"
                color="sky"
                bar={Math.min(1, vehicle.speed / 130)}
              />
              <TelemetryCard
                icon={<Navigation className="w-4 h-4" />}
                label="Bearing / Heading"
                value={vehicle.bearing.toFixed(0)}
                unit="°"
                color="teal"
                compass={vehicle.bearing}
              />
              <TelemetryCard
                icon={<Mountain className="w-4 h-4" />}
                label="Elevation"
                value={vehicle.elevation.toFixed(1)}
                unit="m"
                color="emerald"
                bar={Math.min(1, (vehicle.elevation + 10) / 40)}
              />
              <TelemetryCard
                icon={<Waves className="w-4 h-4" />}
                label="Proximity Delta"
                value={vehicle.proximityDelta.toFixed(2)}
                unit="m"
                color={vehicle.proximityDelta > 15 ? 'rose' : 'amber'}
                bar={Math.min(1, vehicle.proximityDelta / 40)}
                sublabel="raw ↔ matched"
              />

              {/* Mini chart: confidence over recent history */}
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-semibold text-white">Confidence Trend</span>
                </div>
                <Sparkline
                  data={(snap?.history ?? []).slice(-60).map((h) => h.confidence)}
                  color="#38bdf8"
                  min={0.6}
                  max={1}
                />
                <div className="flex justify-between mt-2 text-[9px] text-slate-600">
                  <span>60 samples ago</span>
                  <span>now</span>
                </div>
              </Card>

              {/* Road distribution */}
              <Card className="p-4">
                <div className="text-xs font-semibold text-white mb-3">Road Distribution</div>
                {(() => {
                  const hist = snap?.history ?? [];
                  const hw = hist.filter((h) => h.roadClass === 'highway').length;
                  const sr = hist.length - hw;
                  const total = hist.length || 1;
                  return (
                    <div className="space-y-2">
                      <DistRow label="Highway" value={hw / total} count={hw} color="bg-sky-500" />
                      <DistRow label="Service Road" value={sr / total} count={sr} color="bg-teal-400" />
                    </div>
                  );
                })()}
              </Card>

              {/* Raw vs matched sample count */}
              <Card className="p-4">
                <div className="grid grid-cols-2 gap-3">
                  <MiniStat label="GPS Fixes" value={String(snap?.history.length ?? 0)} />
                  <MiniStat
                    label="Avg Error"
                    value={`${((snap?.history ?? []).slice(-30).reduce((a, h) => a + h.error, 0) / Math.max(1, Math.min(30, (snap?.history ?? []).length))).toFixed(1)}m`}
                  />
                </div>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function LegendItem({ color, label, dashed, thin }: { color: string; label: string; dashed?: boolean; thin?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <div
        className="rounded-full"
        style={{
          width: thin ? 14 : 18,
          height: thin ? 2 : 3,
          background: dashed ? 'transparent' : color,
          borderTop: dashed ? `2px dashed ${color}` : undefined,
        }}
      />
      <span className="text-[10px] text-slate-400">{label}</span>
    </div>
  );
}

function TelemetryCard({
  icon,
  label,
  value,
  unit,
  color,
  bar,
  compass,
  sublabel,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  unit: string;
  color: 'sky' | 'teal' | 'emerald' | 'amber' | 'rose';
  bar?: number;
  compass?: number;
  sublabel?: string;
}) {
  const colorMap: Record<string, string> = {
    sky: 'text-sky-400',
    teal: 'text-teal-400',
    emerald: 'text-emerald-400',
    amber: 'text-amber-400',
    rose: 'text-rose-400',
  };
  const barMap: Record<string, string> = {
    sky: 'from-sky-500 to-sky-400',
    teal: 'from-teal-500 to-teal-400',
    emerald: 'from-emerald-500 to-emerald-400',
    amber: 'from-amber-500 to-amber-400',
    rose: 'from-rose-500 to-rose-400',
  };

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2">
          <span className={colorMap[color]}>{icon}</span>
          <span className="text-[11px] text-slate-400 font-medium">{label}</span>
        </div>
        {sublabel && <span className="text-[9px] text-slate-600">{sublabel}</span>}
      </div>
      <div className="flex items-baseline gap-1">
        <span className={`text-2xl font-bold tabular-nums ${colorMap[color]}`}>{value}</span>
        <span className="text-xs text-slate-500 font-medium">{unit}</span>
        {compass !== undefined && (
          <div className="ml-auto relative w-8 h-8">
            <div className="absolute inset-0 rounded-full border border-slate-600/40" />
            <Navigation
              className="w-4 h-4 text-teal-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-transform duration-300"
              style={{ transform: `translate(-50%, -50%) rotate(${compass}deg)` }}
            />
          </div>
        )}
      </div>
      {bar !== undefined && <ProgressBar value={bar} color={barMap[color]} className="mt-2" />}
    </Card>
  );
}

function Sparkline({ data, color, min, max }: { data: number[]; color: string; min: number; max: number }) {
  if (data.length < 2) return <div className="h-12 flex items-center justify-center text-[10px] text-slate-600">collecting...</div>;
  const w = 100;
  const h = 40;
  const range = max - min;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / range) * h;
    return `${x},${y}`;
  });
  const path = `M ${pts.join(' L ')}`;
  const areaPath = `${path} L ${w},${h} L 0,${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-12" preserveAspectRatio="none">
      <defs>
        <linearGradient id="spark-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={areaPath} fill="url(#spark-grad)" />
      <path d={path} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function DistRow({ label, value, count, color }: { label: string; value: number; count: number; color: string }) {
  return (
    <div>
      <div className="flex justify-between text-[10px] mb-1">
        <span className="text-slate-400">{label}</span>
        <span className="text-slate-500 tabular-nums">{count} pts</span>
      </div>
      <div className="h-2 rounded-full bg-slate-700/50 overflow-hidden">
        <div className={`h-full rounded-full ${color} transition-all duration-500`} style={{ width: `${value * 100}%` }} />
      </div>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] text-slate-500 uppercase tracking-wider">{label}</div>
      <div className="text-sm font-bold text-white tabular-nums mt-0.5">{value}</div>
    </div>
  );
}
