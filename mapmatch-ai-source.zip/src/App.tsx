import { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import LiveSimulation from '@/tabs/LiveSimulation';
import AlgorithmAnalytics from '@/tabs/AlgorithmAnalytics';
import GpsErrorMetrics from '@/tabs/GpsErrorMetrics';
import DatasetExplorer from '@/tabs/DatasetExplorer';

export type TabId = 'live' | 'analytics' | 'errors' | 'datasets';

export default function App() {
  const [tab, setTab] = useState<TabId>('live');

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#070b14] text-slate-200">
      <Sidebar active={tab} onChange={setTab} />
      <main className="flex-1 overflow-y-auto scrollbar-thin">
        {tab === 'live' && <LiveSimulation />}
        {tab === 'analytics' && <AlgorithmAnalytics />}
        {tab === 'errors' && <GpsErrorMetrics />}
        {tab === 'datasets' && <DatasetExplorer />}
      </main>
    </div>
  );
}
